/*____________________________
 BLAKK - Remote Player Mode (continued)
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/

#include <lib/std.mi>

Global Layout mainremote;
Global Group VolGroup, TracktextsGroup;
Global Int voling;
Global String HittenVol;
Global slider remotehidvol;
Global layer Vol,volfull;
Global map volmap;
Global region volregion;
Function volumeBBinit();
Function setTempText2(String txt, String txt2);
Function emptyTempText2();
Global Text ArtistText, TitleText, HiddenTicker;
Global Timer ArtistTexttimer2;

Class GuiObject HintObject;
Global HintObject RemoteEQBtonText, RemoteMLBtonText, RemotePLBtonText;
Global Togglebutton RemoteTogPL, RemoteTogML, RemoteTogEQ;
Global Group TogglesGroup;

Global Togglebutton RemoteMuteBtn;
Global Float VolumeLevel;
Global Boolean Muted, BtnPressed;

System.onScriptLoaded() {
 
 	mainremote = getContainer("main").getLayout("remote");
	VolGroup = mainremote.getObject("blakk.volume.group");
	
	remotehidvol = VolGroup.getObject("blakk.remote.hidvol");
	vol = VolGroup.getObject("blakk.remote.vol-empty");
	volfull = VolGroup.getObject("blakk.remote.vol-full");
	volregion = New Region;
	volregion.loadfrombitmap("player.remote-volume-region");
	vol.setregion(volregion);
	volmap = New Map;
	volmap.loadmap("player.remote-volume-map");
	
	ArtistTexttimer2 = new Timer;
 	ArtistTexttimer2.setDelay(1000);
	
	TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	ArtistText = TracktextsGroup.getObject("ArtistText");
	TitleText = TracktextsGroup.getObject("TitleText");
	HiddenTicker = TracktextsGroup.getObject("hiddenTicker");
	
	TogglesGroup = mainremote.getObject("blakk.remote-toggles.group");
	RemoteTogPL = TogglesGroup.getObject("blakk.remote.toggle-pl");
	RemoteTogML = TogglesGroup.getObject("blakk.remote.toggle-ml");
	RemoteTogEQ = TogglesGroup.getObject("blakk.remote.toggle-eq");
	RemoteEQBtonText = TogglesGroup.getObject("blakk.remote.eq-text");
	RemoteMLBtonText = TogglesGroup.getObject("blakk.remote.ml-text");
	RemotePLBtonText = TogglesGroup.getObject("blakk.remote.pl-text");

	RemoteMuteBtn = TogglesGroup.getObject("blakk.remote-toggle-mute");
	//Muted = 0;
	Muted = getPrivateInt("BLAKK", "muted", 0); 
    VolumeLevel = getPrivateInt("BLAKK", "old_volume", 0); 
	RemoteMuteBtn.setActivated(Muted);
	BtnPressed = 0; 	

//		TitleText.setText(System.getPlayItemMetaDataString("title"));
//		ArtistText.setText(System.getPlayItemMetaDataString("artist"));
	string s = hiddenTicker.getText();	
	int v = strsearch(s, " - ");			
	string s1 = strleft (s, v);
	string s2 = strright (s, strlen(s) - 3 - v);
	ArtistText.setText(s1);
	TitleText.setText(s2);
}
	
	System.onScriptUnloading(){
	delete ArtistTexttimer2;
	setPrivateInt("BLAKK", "muted", Muted); 
    setPrivateInt("BLAKK", "old_volume", VolumeLevel);
}


// Volume Maped Slider
vol.onleftbuttondown(int x, int y){
 voling=1;
 x = x-vol.getleft();
 y = y-vol.gettop();
 if (volmap.inregion(x,y)){
  int c = volmap.getvalue(x,y);
  volfull.setregionfrommap(volmap,c,1);
  setvolume(c);
 } 
}
vol.onleftbuttonup(int x, int y){voling=0;}
vol.onmousemove(int x, int y){
 if (voling){
  x = x-vol.getleft();
  y = y-vol.gettop();
  if (volmap.inregion(x,y)){
   int c = volmap.getvalue(x,y);
   volfull.setregionfrommap(volmap,c,1);
   setvolume(c);
  } 
 }
}

remotehidvol.onpostedposition(int p){
 volfull.setregionfrommap(volmap,p,1); 
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempText2("Volume:", System.integerToString(f) + "%");
}

volumeBBinit(){
 int c = getvolume();
 volfull.setregionfrommap(volmap,c,1);
}   


ArtistTexttimer2.onTimer() {
			string s = hiddenTicker.getText();	
			int v = strsearch(s, " - ");			
			string s1 = strleft (s, v);
			string s2 = strright (s, strlen(s) - 3 - v);
			ArtistText.setText(s1);
			TitleText.setText(s2);

			stop();
}

setTempText2(String txt, String txt2) {
  ArtistTexttimer2.stop();
  ArtistText.setText(txt);
  TitleText.setText(txt2);
  ArtistTexttimer2.start();
}

emptyTempText2() {
			string s = hiddenTicker.getText();	
			int v = strsearch(s, " - ");			
			string s1 = strleft (s, v);
			string s2 = strright (s, strlen(s) - 3 - v);
			ArtistText.setText(s1);
			TitleText.setText(s2);

			ArtistTexttimer2.stop();
}


//  EQ, ML & PL down states
	RemoteTogEQ.onLeftButtonDown(int x, int y) {
		RemoteEQBtonText.setXMLParam("y", "199" );
	}
	RemoteTogEQ.onLeftButtonUp(int x, int y) {
		RemoteEQBtonText.setXMLParam("y", "198" );
	}
	
	
	RemoteTogML.onLeftButtonDown(int x, int y) {
		RemoteMLBtonText.setXMLParam("y", "199" );
	}
	RemoteTogML.onLeftButtonUp(int x, int y) {
		RemoteMLBtonText.setXMLParam("y", "198" );
	}	
	
	RemoteTogPL.onLeftButtonDown(int x, int y) {
		RemotePLBtonText.setXMLParam("y", "199" );
	}
	RemoteTogPL.onLeftButtonUp(int x, int y) {
		RemotePLBtonText.setXMLParam("y", "198" );
	}

// Mute button	
RemoteMuteBtn.onLeftButtonUp(int x, int y) {
	BtnPressed = 1; 
	if (!Muted) { 
		VolumeLevel = System.getVolume();
		System.setVolume(0);
		Muted = 1;
	} else { 
		System.setVolume(VolumeLevel);
		Muted = 0;
	}
}

System.onvolumechanged(int newvol) 
{ 
    if (!BtnPressed) { 
        if (Muted) { 
            RemoteMuteBtn.setActivated(0); 
            Muted = 0; 
        } 
    } 
    BtnPressed = 0; 
} 

System.onKeyDown(String key) { 
    if (key == "ctrl+m") 
    { 
        RemoteMuteBtn.LeftClick(); 
    } 
}