for %%a in (*.m) do "C:\Program Files\Winamp\mc.exe" %%a
pause
