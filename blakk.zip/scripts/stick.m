/*____________________________
 BLAKK - Remote Stick Mode
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/

#include <lib/std.mi>

Global Layout mainstick;
Global Button StckPlay, StckPause, StckStop, StckEject;

Global Int voling_stck;
Global String HittenVol;
Global slider hidvol;
Global layer Vol,volStckfull;
Global map volStckmap;
Global region volStckregion;
Function volumeStickInit();
Function setTempTextStck(String txt);
Function emptyTempTextStck();
Global Text StickTicker;
Global Timer StickTickerTimer;
Global int isMovingStck;

Global Slider Seeker, SeekGhost;
Global Int Seeking;

System.onScriptLoaded() {
 	mainstick = getContainer("main").getLayout("stick");
	StckPlay = mainstick.getObject("blakk.stick-play");
	StckPause = mainstick.getObject("blakk.stick-pause");
	StckStop = mainstick.getObject("blakk.stick-stop");
	StckEject = mainstick.getObject("blakk.stick-eject");
	StickTicker = mainstick.getObject("Songticker");
	
	hidvol = mainstick.getObject("blakk.stick.hidvol");
	vol = mainstick.getObject("blakk.stick-volume-min");
	volStckfull = mainstick.getObject("blakk.stick-volume-max");
	volStckregion = New Region;
	volStckregion.loadfrombitmap("player.stick-volume-region");
	vol.setregion(volStckregion);
	volStckmap = New Map;
	volStckmap.loadmap("player.stick-volume-map");

	volumeStickInit();	
		
	StickTickerTimer = new Timer;
 	StickTickerTimer.setDelay(1000);
	
	int sysStat;
	sysStat = System.getStatus();
	if (sysStat==-1) {
		StckPlay.show();
		StckPause.hide();
		StckEject.hide();
		StckStop.show();
		}
	if (sysStat==0) {
		StckPlay.show();
		StckPause.hide();
		StckEject.show();
		StckStop.hide();		
		}
	if (sysStat==1) {
		StckPlay.hide();
		StckPause.show();
		StckEject.hide();
		StckStop.show();	
		}	
		
	isMovingStck = 0;

	Seeker = mainstick.getObject("Seeker");
	SeekGhost = mainstick.getObject("SeekerGhost");	

	if (SeekGhost != NULL)
		SeekGhost.setAlpha(1);	
}


System.onScriptUnloading(){
	//delete songInfoTimer;
	delete StickTickerTimer;
}
 
// Playpause buttons
System.onPlay(){
	StckPlay.hide();
	StckPause.show();
	StckEject.hide();
	StckStop.show();		
}

System.onStop(){
	StckPlay.show();
	StckPause.hide();
	StckEject.show();
	StckStop.hide();		
}

System.onResume(){
	StckPlay.hide();
	StckPause.show();
	StckEject.hide();
	StckStop.show();	
}

System.onPause(){
	StckPlay.show();
	StckPause.hide();
	StckEject.hide();
	StckStop.show();	
}


// Seeker
Seeker.onSetPosition(int p) {
  if (!SeekGhost && seeking) {
    Float f;
    f = p;
    f = f / 255 * 100;
    Float len = getPlayItemLength();
    if (len != 0) {
      int np = len * f / 100;
      setTempTextStck(integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
    }
  }
}

Seeker.onLeftButtonDown(int x, int y) {
  seeking = 1;
}

Seeker.onLeftButtonUp(int x, int y) {
  seeking = 0;
  setTempTextStck("");
}

SeekGhost.onSetPosition(int p) {
  if (getalpha() == 1) return;
  Float f;
  f = p;
  f = f / 255 * 100;
  Float len = getPlayItemLength();
  if (len != 0) {
    int np = len * f / 100;
    setTempTextStck(integerToTime(np) + " / " + integerToTime(len) + " (" + integerToString(f) + "%)");
  }
}

SeekGhost.onLeftButtonDown(int x, int y) {
  SeekGhost.setAlpha(128);
}

SeekGhost.onLeftButtonUp(int x, int y) {
  SeekGhost.setAlpha(1);
}

Seeker.onSetFinalPosition(int p) {
  StickTicker.setText("");
}

SeekGhost.onsetfinalposition(int p) {
  StickTicker.setText("");
  SeekGhost.setAlpha(1);
}

SeekGhost.onEnterArea() {
	StickTicker.setXMLParam("display", "time");
	}
	
SeekGhost.onLeaveArea() {
	StickTicker.setXMLParam("display", "songname");
	}

	
// Volume Maped Slider
vol.onleftbuttondown(int x, int y){
 voling_stck=1;
 x = x-vol.getleft();
 y = y-vol.gettop();
 if (volStckmap.inregion(x,y)){
  int c = volStckmap.getvalue(x,y);
  volStckfull.setregionfrommap(volStckmap,c,1);
  setvolume(c);
 } 
}
vol.onleftbuttonup(int x, int y){voling_stck=0;}
vol.onmousemove(int x, int y){
 if (voling_stck){
  x = x-vol.getleft();
  y = y-vol.gettop();
  if (volStckmap.inregion(x,y)){
   int c = volStckmap.getvalue(x,y);
   volStckfull.setregionfrommap(volStckmap,c,1);
   setvolume(c);
  } 
 }
}

hidvol.onpostedposition(int p){
 volStckfull.setregionfrommap(volStckmap,p,1); 
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempTextStck("Volume: " + System.integerToString(f) + "%");
}

volumeStickInit(){
 int c = getvolume();
 volStckfull.setregionfrommap(volStckmap,c,1);
}   

/*   
hidvol.onPostedPosition(int p) {
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempTextStck("Volume: " + System.integerToString(f) + "%");
}
*/


StickTickerTimer.onTimer() {
  StickTicker.setText("");
  stop();
}

setTempTextStck(String txt) {
  StickTickerTimer.stop();
  StickTicker.setText(txt);
  StickTickerTimer.start();
}

emptyTempTextStck() {
  StickTicker.setText("");
  StickTickerTimer.stop();
}

