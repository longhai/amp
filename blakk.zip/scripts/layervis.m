//----------------------------------------------------------------------------------------
//
// layervis.m
//
//----------------------------------------------------------------------------------------
// Use like this :
// #define LAYER_VIS_VAR MyVar
// #include "simpledragvolume.m"
//
//
//                       _MyVarInitLEFT(Layer l, Map ml);          // init Left EQ
//                       _MyVarInitCENTER(Layer l, Map ml);        // init Center EQ
//                       _MyVarInitRIGHT(Layer l, Map ml);         // init Right EQ
//                       _MyVarStart();                            // starts it
//                       _MyVarShutdown();                         // ends it
//



Global Layer _##LAYER_VIS_VAR##LayerLEFT;
Global Layer _##LAYER_VIS_VAR##LayerCENTER;
Global Layer _##LAYER_VIS_VAR##LayerRIGHT;

Global Map _##LAYER_VIS_VAR##MapLEFT;
Global Map _##LAYER_VIS_VAR##MapCENTER;
Global Map _##LAYER_VIS_VAR##MapRIGHT;

Function _##LAYER_VIS_VAR##InitLEFT(Layer l, Map ml);
Function _##LAYER_VIS_VAR##InitCENTER(Layer c, Map mc);
Function _##LAYER_VIS_VAR##InitRIGHT(Layer r, Map mr);
Function _##LAYER_VIS_VAR##Update( Layer eq, Map eqmap, Int value);
Function _##LAYER_VIS_VAR##Start();
Function _##LAYER_VIS_VAR##Shutdown();

Global Int _##LAYER_VIS_VAR##isLEFT, _##LAYER_VIS_VAR##isCENTER, _##LAYER_VIS_VAR##isRIGHT;

Global Timer _##LAYER_VIS_VAR##refreshEQ;

_##LAYER_VIS_VAR##InitLEFT(Layer l, Map ml) {
  _##LAYER_VIS_VAR##LayerLEFT = l;
  _##LAYER_VIS_VAR##MapLEFT = ml;
  _##LAYER_VIS_VAR##isLEFT = 1;
}

_##LAYER_VIS_VAR##InitCENTER(Layer c, Map mc) {
  _##LAYER_VIS_VAR##LayerCENTER = c;
  _##LAYER_VIS_VAR##MapCENTER = mc;
  _##LAYER_VIS_VAR##isCENTER = 1;
}

_##LAYER_VIS_VAR##InitRIGHT(Layer r, Map mr) {
  _##LAYER_VIS_VAR##LayerRIGHT = r;
  _##LAYER_VIS_VAR##MapRIGHT = mr;
  _##LAYER_VIS_VAR##isRIGHT = 1;
}

_##LAYER_VIS_VAR##Start() {
  _##LAYER_VIS_VAR##refreshEQ = new Timer;
  _##LAYER_VIS_VAR##refreshEQ.setDelay(25);
  _##LAYER_VIS_VAR##refreshEQ.start();
}

_##LAYER_VIS_VAR##LayerLEFT.onLeftButtonDown(int x, int y) {
  if (_##LAYER_VIS_VAR##isLEFT != 0) { 
      _##LAYER_VIS_VAR##isLEFT = 0;
      _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerLEFT, _##LAYER_VIS_VAR##MapLEFT, 0 );
  } else {
      _##LAYER_VIS_VAR##isLEFT = 1;
  }
}

_##LAYER_VIS_VAR##LayerCENTER.onLeftButtonDown(int x, int y) {
  if (_##LAYER_VIS_VAR##isCENTER != 0) { 
      _##LAYER_VIS_VAR##isCENTER = 0;
      _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerCENTER, _##LAYER_VIS_VAR##MapCENTER, 0 );
  } else {
      _##LAYER_VIS_VAR##isCENTER = 1;
  }
}

_##LAYER_VIS_VAR##LayerRIGHT.onLeftButtonDown(int x, int y) {
  if (_##LAYER_VIS_VAR##isRIGHT != 0) { 
      _##LAYER_VIS_VAR##isRIGHT = 0;
      _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerRIGHT, _##LAYER_VIS_VAR##MapRIGHT, 0 );
  } else {
      _##LAYER_VIS_VAR##isRIGHT = 1;
  }
}

_##LAYER_VIS_VAR##refreshEQ.onTimer() {

  int l = getPlayItemLength();
  if (l > 0) {
    if (_##LAYER_VIS_VAR##isLEFT != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerLEFT, _##LAYER_VIS_VAR##MapLEFT, System.getLeftVuMeter() );
    if (_##LAYER_VIS_VAR##isCENTER != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerCENTER, _##LAYER_VIS_VAR##MapCENTER, (System.getLeftVuMeter() + System.getRightVuMeter() ) / 2 );
    if (_##LAYER_VIS_VAR##isRIGHT != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerRIGHT, _##LAYER_VIS_VAR##MapRIGHT, System.getRightVuMeter() );
  } else {
    if (_##LAYER_VIS_VAR##isLEFT != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerLEFT, _##LAYER_VIS_VAR##MapLEFT, 0 );
    if (_##LAYER_VIS_VAR##isCENTER != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerCENTER, _##LAYER_VIS_VAR##MapCENTER, 0 );
    if (_##LAYER_VIS_VAR##isRIGHT != 0) _##LAYER_VIS_VAR##Update( _##LAYER_VIS_VAR##LayerRIGHT, _##LAYER_VIS_VAR##MapRIGHT, 0 );
  }
}

_##LAYER_VIS_VAR##Update( Layer eq, Map eqmap, Int value) {
  Region r = new Region;
  r.loadFromMap(eqmap, value, 1);
  eq.setRegion(r);
  delete r;
}

_##LAYER_VIS_VAR##Shutdown() {
  delete _##LAYER_VIS_VAR##refreshEQ;
}
