/*____________________________
 BLAKK - Boombox Player Mode
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/


#include <lib/std.mi>
#define LAYER_VIS_VAR MainVis
#include "layervis.m"

Global Group ControlsGroup, SpecVolGroup, VolGroup, SpecGroup;
Global Layout main_boombox;
Global Button Bbox_prev,Bbox_play,Bbox_pause,Bbox_stop,Bbox_next,Bbox_eject;
Global Layer control_bton_glow, left, right;
Global Double dp_left, dp_right;

Class Layer HintLayer;
Global Map VisMapLeft;
Global Map VisMapRight;
Global HintLayer VisLeft, VisRight;

Function setTempText(String txt);
Function emptyTempText();
Function updateSeeker(int x, int y, map seekmap, layer seek1, text Songticker);
Global Text Songticker;
Global Timer Songtickertimer;
Global Int seeking, now;
Global String Hitten;
Global slider hidseek;
Global layer seek1,seekfull;
Global map seekmap;
Global region seekregion;

Global Layer DisplayBase;
Global Group SpecVolGroup, SpecGroup, VolGroup;


System.onScriptLoaded() {
	
	ControlsGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.controls");

	Bbox_prev = ControlsGroup.findObject("Previous");
	Bbox_play = ControlsGroup.findObject("Play");
	Bbox_stop = ControlsGroup.findObject("Stop");
	Bbox_pause = ControlsGroup.findObject("Pause");
	Bbox_next = ControlsGroup.findObject("Next");
	Bbox_eject = ControlsGroup.findObject("Eject");
	control_bton_glow = ControlsGroup.findObject("bb-ctrol-bton-glow");
    
    left = getContainer("main").getLayout("boombox").findObject("LeftSpeaker");;
    right = getContainer("main").getLayout("boombox").findObject("RightSpeaker");;
    right.fx_setBilinear(1);
    right.fx_setLocalized(1);
    right.fx_setRealtime(1);
    right.fx_setSpeed(60);
    right.fx_setGridSize(10,10);
 
    left.fx_setBilinear(1);
    left.fx_setLocalized(1);
    left.fx_setRealtime(1);
    left.fx_setSpeed(60);
    left.fx_setGridSize(10,10);

    SpecVolGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.SpecVol");
    SpecGroup = SpecVolGroup.getObject("blakk.bb.group.Spec");

    VisLeft = SpecGroup.getObject("bb-spectrum-left");
    VisRight = SpecGroup.getObject("bb-spectrum-right");
    VisMapLeft = new Map;
    VisMapRight = new Map;
    VisMapLeft.loadMap("player.bb-spectrum-left-map");
    VisMapRight.loadMap("player.bb-spectrum-right-map");

    _MainVisInitLEFT(VisLeft, VisMapLeft);
    _MainVisInitRIGHT(VisRight, VisMapRight);
    _MainVisStart();

	Songtickertimer = new Timer;
 	Songtickertimer.setDelay(1000);

	Group SeekerGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.seek");
 	hidseek = SeekerGroup.getObject("blakk.bb.shadehidseek");
	seek1 = SeekerGroup.getObject("blakk.bb.seek-empty");
 	seekfull = SeekerGroup.getObject("blakk.bb.seek-full");
 	seekregion = New Region;
 	seekregion.loadfrombitmap("player.bb-seek-region");
 	seek1.setregion(seekregion);
 	seekmap = New Map;
 	seekmap.loadmap("player.bb-seek-map");
 	Songticker = getContainer("main").getLayout("boombox").findObject("Songticker");
 	seekfull.hide();

    SpecVolGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.SpecVol");
 	VolGroup = SpecVolGroup.getObject("blakk.bb.group.vol");
 	DisplayBase = getContainer("main").getLayout("boombox").getObject("black-bb-displayBase");
}

System.onScriptUnLoading() {
	_MainVisShutdown();
 
	delete Songtickertimer;
}


// Control Click Glows	
	Bbox_next.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "286");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_next.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
    }
	
	Bbox_eject.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "252");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_eject.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
	}
	
		
	Bbox_stop.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "218");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_stop.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
	}

		
	Bbox_pause.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "184");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_pause.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
	}
	
		
	Bbox_play.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "150");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_play.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
	}	
	
		
	Bbox_prev.onLeftButtonDown(int x, int y) {
		control_bton_glow.setXMLParam("x", "116");
		control_bton_glow.setXMLParam("y", "134");
		control_bton_glow.setAlpha(255);
    }
	Bbox_prev.onLeftButtonUp(int x, int y) {
		control_bton_glow.setAlpha(0);
	}

	
//	Speaker layer fx
    Right.fx_onGetPixelD(double r, double d, double x, double y) {
        return d*(1.2-sin(dp_right));
    }

    Left.fx_onGetPixelD(double r, double d, double x, double y) {
        return d*(1.2-sin(dp_left));
    }

    Left.fx_onFrame() {
        dp_left = system.getLeftVuMeter()/575;
    }

    Right.fx_onFrame() {
        dp_right = system.getRightVuMeter()/575;
    }

    left.onSetVisible(int v) {
        Left.fx_setEnabled(v);
    }

    right.onSetVisible(int v) {
        Right.fx_setEnabled(v);
    } 	

	
// Song Position Seeker (don't like anims with maps)
	seek1.onleftbuttondown(int x, int y) {
		seeking = 1;
 		x= x-seek1.getleft();
 		y= y-seek1.gettop();
 		if (seekmap.inregion(x,y)) {
  			now= seekmap.getvalue(x,y);
  			seekfull.setregionfrommap(seekmap,now,1);
 			updateSeeker(x, y, seekmap, seek1, Songticker);
 		}
	}

	seek1.onmousemove(int x, int y){
 		if (seeking) {
  			x= x-seek1.getleft();
  			y= y-seek1.gettop();
  				if (seekmap.inregion(x,y)) {
   					now= seekmap.getvalue(x,y);
   					seekfull.setregionfrommap(seekmap,now,1);
   					updateSeeker(x, y, seekmap, seek1, Songticker);
   				}
 		}
	}

	seek1.onleftbuttonup(int x, int y){
 		now = now/255*system.getplayitemlength();
 		seekto(now);
 		seeking=0;
 		Songtickertimer.start();
	}

	hidseek.onpostedposition(int p){
 		if (!seeking){
	 		seekfull.show();seekfull.setregionfrommap(seekmap,p,1);
	 	}
	}

	System.onstop(){
 		seekfull.hide();
	}


	Songtickertimer.onTimer() {
  		Songticker.setText("");
  		stop();
	}


	/*  
	seek1.onleftbuttondown(int x, int y) {
		if (!seeking) {
    		now = now/255*system.getplayitemlength();
			updateSeeker(x, y);
  		}
	}
	*/


	seek1.onLeftButtonUp(int x, int y) {
  		seeking = 0;
  		setTempText("");
	} 

	/*
	updateSeeker(int x, int y, map seekmap, layer seek1, text Songticker) {
		int v = seekmap.getValue(x - seek1.getLeft(), y - seek1.getTop());
		if (v > 0) {
			if (System.getPlayItemLength() >= 0) {
				float len = System.getPlayItemLength();
				int p = (v * 100) / 255;
				int s = (v * len) / 255;
				Songticker.setText("Seek " + System.integerToTime(s));
			}
		}
	}
	*/

	updateSeeker(int x, int y, map seekmap, layer seek1, text Songticker) {
		int v = seekmap.getValue(x, y);
		if (v > 0) {
			if (System.getPlayItemLength() >= 0) {
				float len = System.getPlayItemLength();
				int p = (v * 100) / 255;
				int s = (v * len) / 255;
				setTempText("Seek to: " + System.integerToTime(s) + " / " + System.integerToTime(len));
			}
		}
	}

	hidseek.onSetFinalPosition(int p) {
		Songticker.setText("");
	}

	setTempText(String txt) {
  		Songtickertimer.stop();
  		Songticker.setText(txt);
  		Songtickertimer.start();
	}

	emptyTempText() {
  		Songticker.setText("");
  		Songtickertimer.stop();
	}
