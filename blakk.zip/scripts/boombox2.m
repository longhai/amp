/*____________________________
 BLAKK - Boombox Player Mode (continued)
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/
#include <lib/std.mi>

Global Group ControlsGroup, SpecVolGroup, VolGroup, SpecGroup;
Global Int voling;
Global String HittenVol;
Global slider hidvol;
Global layer Vol,volfull;
Global map volmap;
Global region volregion;
Function volumeBBinit();
Function setTempText2(String txt);
Function emptyTempText2();
Global Text Songticker;
Global Timer Songtickertimer2;


Class GuiObject HintObject;
Global HintObject Bbox_prev,Bbox_play,Bbox_pause,Bbox_stop,Bbox_next,Bbox_eject, Bbox_base, TickerText, TimerText, SeekEmpty, volMin, SpecLeft, SpecRight, TogPL, TogML, TogEQ, TogXBS, AltMenuBton, MinBton, SwitchBton, CloseBton;
Global Layout mainBbox;
Function moveDrawer();
Function moveDrawerBack();
Function lockDrawer();
Function MoveTolockDrawer();
Function unlockDrawer();
Global Timer moveDrawerBackTimer;
Global int isMoving;

Global HintObject EQBtonText, MLBtonText, PLBtonText;
Global Togglebutton TogPL2, TogML2, TogEQ2;

System.onScriptLoaded() {

    SpecVolGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.SpecVol");
    SpecGroup = SpecVolGroup.getObject("blakk.bb.group.Spec");
 	VolGroup = SpecVolGroup.getObject("blakk.bb.group.vol");
 	Songticker = getContainer("main").getLayout("boombox").findObject("Songticker");

	hidvol = VolGroup.getObject("hidvol");
	vol = VolGroup.getObject("blakk.bb.vol-min");
	volfull = VolGroup.getObject("blakk.bb.vol-max");
	volregion = New Region;
	volregion.loadfrombitmap("player.bb-volume-region");
	vol.setregion(volregion);
	volmap = New Map;
	volmap.loadmap("player.bb-volume-map");

	volumeBBinit();

	Songtickertimer2 = new Timer;
 	Songtickertimer2.setDelay(1000);

	ControlsGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.controls");

	Bbox_prev = ControlsGroup.findObject("Previous");
	Bbox_play = ControlsGroup.findObject("Play");
	Bbox_stop = ControlsGroup.findObject("Stop");
	Bbox_pause = ControlsGroup.findObject("Pause");
	Bbox_next = ControlsGroup.findObject("Next");
	Bbox_eject = ControlsGroup.findObject("Eject");
	
	moveDrawerBackTimer = new Timer;
	moveDrawerBackTimer.setDelay(1000);
	
	Bbox_base = getContainer("main").getLayout("boombox").getObject("blakk-bb-base");

 	TickerText = getContainer("main").getLayout("boombox").findObject("Songticker");
 	TimerText = getContainer("main").getLayout("boombox").findObject("timer");
	Group SeekerGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.seek");
    Group SpecVolGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.SpecVol");
 	SeekEmpty = SeekerGroup.getObject("blakk.bb.seek-empty");
	volMin = VolGroup.getObject("blakk.bb.vol-min");
    SpecVolGroup = getContainer("main").getLayout("boombox").getObject("blakk.bb.group.SpecVol");
    SpecGroup = SpecVolGroup.getObject("blakk.bb.group.Spec");
    SpecLeft = SpecGroup.getObject("bb-spectrum-left");
    SpecRight = SpecGroup.getObject("bb-spectrum-right");
	
	mainBbox = getContainer("main").getLayout("boombox");
	TogPL = mainBbox.getObject("blakk.bb.toggle-pl");
	TogML = mainBbox.getObject("blakk.bb.toggle-ml");
	TogEQ = mainBbox.getObject("blakk.bb.toggle-eq");
	TogXBS = mainBbox.getObject("blakk.bb.XBS");
	AltMenuBton = mainBbox.getObject("blakk-alt-bton");
	MinBton = mainBbox.getObject("blakk-min-bton");
	SwitchBton = mainBbox.getObject("blakk-switch-bton");
	CloseBton = mainBbox.getObject("blakk-close-bton");
	
	EQBtonText = mainBbox.getObject("blakk.bb.eq-text");
	MLBtonText = mainBbox.getObject("blakk.bb.ml-text");
	PLBtonText = mainBbox.getObject("blakk.bb.pl-text");
	
	TogPL2 = mainBbox.getObject("blakk.bb.toggle-pl");
	TogML2 = mainBbox.getObject("blakk.bb.toggle-ml");
	TogEQ2 = mainBbox.getObject("blakk.bb.toggle-eq");
	isMoving = 0;
}

System.onScriptUnLoading() {
	delete Songtickertimer2;
	delete moveDrawerBackTimer;
}


// Volume Maped Slider
vol.onleftbuttondown(int x, int y){
 voling=1;
 x = x-vol.getleft();
 y = y-vol.gettop();
 if (volmap.inregion(x,y)){
  int c = volmap.getvalue(x,y);
  volfull.setregionfrommap(volmap,c,1);
  setvolume(c);
 } 
}
vol.onleftbuttonup(int x, int y){voling=0;}
vol.onmousemove(int x, int y){
 if (voling){
  x = x-vol.getleft();
  y = y-vol.gettop();
  if (volmap.inregion(x,y)){
   int c = volmap.getvalue(x,y);
   volfull.setregionfrommap(volmap,c,1);
   setvolume(c);
  } 
 }
}

hidvol.onpostedposition(int p){
 volfull.setregionfrommap(volmap,p,1); 
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempText2("Volume: " + System.integerToString(f) + "%");
}

volumeBBinit(){
 int c = getvolume();
 volfull.setregionfrommap(volmap,c,1);
}   

/*   
hidvol.onPostedPosition(int p) {
  Float f;
  f = p;
  f = f / 255 * 100;
  setTempText2("Volume: " + System.integerToString(f) + "%");
}
*/


Songtickertimer2.onTimer() {
	SongTicker.setText("");
	stop();
}

setTempText2(String txt) {
	Songtickertimer2.stop();
	Songticker.setText(txt);
	Songtickertimer2.start();
}

emptyTempText2() {
	Songticker.setText("");
	Songtickertimer2.stop();
}

// MouseOver Drawers
moveDrawer() {
	isMoving = 1;	 
	SpecGroup.cancelTarget();
	VolGroup.cancelTarget();		
	SpecGroup.setTargetY(-14);
	VolGroup.setTargetY(-14);
	SpecGroup.setTargetSpeed(0.5);
	VolGroup.setTargetSpeed(0.5);
	SpecGroup.gotoTarget();
	VolGroup.gotoTarget();
	lockDrawer();
}
	
moveDrawerBack() {
 	isMoving = 0;
	SpecGroup.cancelTarget();
	VolGroup.cancelTarget();		
	SpecGroup.setTargetY(0);
	VolGroup.setTargetY(14);
	SpecGroup.setTargetSpeed(0.5);
	VolGroup.setTargetSpeed(0.5);
	SpecGroup.gotoTarget();
	VolGroup.gotoTarget();
	moveDrawerBackTimer.stop();
}	
	
moveDrawerBackTimer.onTimer() {
  		moveDrawerBack();	
}

/*
		SpecGroup.onTargetReached()  {
			if (isMoving) {
				moveDrawerBackTimer.stop();
				SpecGroup.setXMLParam("y", "-14");
				VolGroup.setXMLParam("y", "-14");
			} else {
				//	moveDrawerBackTimer.start();
				//moveDrawerBackTimer.stop();
				//SpecGroup.setXMLParam("y", "0");
				//VolGroup.setXMLParam("y", "0");
				SpecGroup.setXMLParam("y", "0");
				VolGroup.setXMLParam("y", "14");				
				
			}
		}	

*/		
lockDrawer() {
	moveDrawerBackTimer.stop();
	SpecGroup.setXMLParam("y", "-14");
	VolGroup.setXMLParam("y", "-14");
}

unlockDrawer() {
	moveDrawerBackTimer.start();
}

Bbox_base.onEnterArea() {
	moveDrawerBackTimer.stop();
	moveDrawer();
}
	
Bbox_base.onLeaveArea() {
	unlockDrawer();
}	
	
MoveTolockDrawer() {
	if (!isMoving) {
		SpecGroup.cancelTarget();
		VolGroup.cancelTarget();
		SpecGroup.setTargetY(-14);
		VolGroup.setTargetY(-14);
		SpecGroup.setTargetSpeed(0.5);
		VolGroup.setTargetSpeed(0.5);
		SpecGroup.gotoTarget();
		VolGroup.gotoTarget();
	}
}
	
/*These help to keep the volume slider visible while over elements on the player, sucks to have the flashing though, will fix later */
HintObject.onEnterArea() {
	if (HintObject == Bbox_prev) MoveTolockDrawer(); 
	else if (HintObject == Bbox_play) MoveTolockDrawer();
	else if (HintObject == Bbox_pause) MoveTolockDrawer();
	else if (HintObject == Bbox_stop) MoveTolockDrawer();
	else if (HintObject == Bbox_next) MoveTolockDrawer();
	else if (HintObject == Bbox_eject) MoveTolockDrawer();
	else if (HintObject == TickerText) MoveTolockDrawer();
	else if (HintObject == TimerText) MoveTolockDrawer();
	else if (HintObject == SeekEmpty) MoveTolockDrawer();
	else if (HintObject == volMin) MoveTolockDrawer();
	else if (HintObject == SpecLeft) MoveTolockDrawer();
	else if (HintObject == SpecRight) MoveTolockDrawer();
	else if (HintObject == TogPL) MoveTolockDrawer();
	else if (HintObject == TogML) MoveTolockDrawer();
	else if (HintObject == TogEQ) MoveTolockDrawer();
	else if (HintObject == AltMenuBton) MoveTolockDrawer();
	else if (HintObject == MinBton) MoveTolockDrawer();
	else if (HintObject == SwitchBton) MoveTolockDrawer();
	else if (HintObject == CloseBton) MoveTolockDrawer();
}

TogEQ.onLeftButtonDown(int x, int y) {
	EQBtonText.setXMLParam("y", "122" );
}

TogEQ.onLeftButtonUp(int x, int y) {
	EQBtonText.setXMLParam("y", "121" );
}
	
TogML.onLeftButtonDown(int x, int y) {
	MLBtonText.setXMLParam("y", "122" );
}

TogML.onLeftButtonUp(int x, int y) {
	MLBtonText.setXMLParam("y", "121" );
}	
	
TogPL.onLeftButtonDown(int x, int y) {
	PLBtonText.setXMLParam("y", "122" );
}

TogPL.onLeftButtonUp(int x, int y) {
	PLBtonText.setXMLParam("y", "121" );
}		
	
TogEQ2.onToggle(boolean on) {
	if (on) {
		//setTempText2("Open Equalizer");
		EQBtonText.setXMLParam("image", "player.bb-toggle-eq-text-on");
	}
	else {
		//setTempText2("Close Equalizer");
		EQBtonText.setXMLParam("image", "player.bb-toggle-eq-text");
	}
}	