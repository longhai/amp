/*____________________________
 BLAKK - Sleep Mode (Remote Player Mode)
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/


#include <lib/std.mi>

Global Layout mainremote;
Global Text TimerTxt;
Global Timer ClockTmr;
Global Group TogglesGroup, SleepGroup;
Global Boolean showTime;
Global Togglebutton SleepBton;
Global Int currentTime, isSleeping;
Global Layer SleepImage, SleepGlass;

System.onScriptLoaded() {

	SleepGroup = getScriptGroup();
	TimerTxt = SleepGroup.findObject("Timer");
	SleepImage = SleepGroup.findObject("blakk.remote-sleepimage");
	SleepGlass = SleepGroup.findObject("blakk.remote-sleepglass");
	mainremote = getContainer("main").getLayout("remote");
	TogglesGroup = mainremote.getObject("blakk.remote-toggles.group");	
	SleepBton = TogglesGroup.getObject("blakk.remote-toggle-sleep");	
	
	ClockTmr = new Timer;
	ClockTmr.setDelay(500);
//	ClockTmr.setDelay(300000);

	showTime = (getplayitemstring() == "");

	if (showTime) {
		ClockTmr.start();
	}
	SleepGroup.hide();
}


System.onScriptLoaded() {
	delete ClockTmr;

}


ClockTmr.onTimer() {
	string longtime = integerToLongTime( getTimeOfDay() );
	string hours, mins, secs, ampm;
	hours = gettoken(longtime,":",0);
	mins = gettoken(longtime,":",1);
	secs = gettoken(longtime,":",2);
	ampm=" pm";
		if (stringtointeger(hours) >= 13) {
			hours = integertostring(stringtointeger(hours) - 12);
		}
		else {
				if (stringtointeger(hours) != 12) {
					ampm=" am";
				}
			if (stringtointeger(hours) == 0) hours = "12";
			}
	longtime = hours + ":" + mins + ":" + secs + ampm;
	TimerTxt.setText (longtime);	
}

SleepBton.onLeftClick()  {
	isSleeping=1;
	SleepGroup.show();
 	SleepImage.setTargetA(255);
	SleepGlass.setTargetA(255);
	
	SleepImage.setTargetSpeed(0.5);
	SleepGlass.setTargetSpeed(0.5);
		
	SleepImage.gotoTarget();
	SleepGlass.gotoTarget();
	ClockTmr.start();
}


SleepImage.onTargetReached()  {
	if (isSleeping) {
		TimerTxt.show();
	} else {
		isSleeping=0;
		SleepBton.setActivated(isSleeping);
		SleepGroup.hide();
		TimerTxt.hide();
	}
}


SleepImage.onLeftButtonDblClk (int x, int y)  {
	isSleeping = 0;
	TimerTxt.hide();
 	SleepImage.setTargetA(0);
	SleepGlass.setTargetA(0);
	
	SleepImage.setTargetSpeed(0.5);
	SleepGlass.setTargetSpeed(0.5);
		
	SleepImage.gotoTarget();
	SleepGlass.gotoTarget();
}

