/*____________________________
 BLAKK - AlbumArt & Big AlbumArt Shifting
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/


#include <lib/std.mi>

Global layer AlbumArt;

Global Layout mainremote;
Global Group infoGroup, TracktextsGroup, SeekerGroup, AlbumArtGroup, VolumeGroup, TogglesGroup; 
Global layer TimerCover, TickerCover, TogglesCover;
Global Timer AlbumShiftTimer, AlbumShiftBackTimer;
Global Boolean BigArt;

System.onScriptLoaded ()
{
	AlbumArt = getScriptGroup().findObject(getParam());

	mainremote = getContainer("main").getLayout("remote");
	infoGroup = mainremote.getObject("blakk.infobox.group");
	SeekerGroup = mainremote.getObject("blakk.seek.group");
	TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	
	TogglesGroup = mainremote.getObject("blakk.remote-toggles.group");		
	AlbumArtGroup = mainremote.getObject("blakk.remote-albumart.group");
	VolumeGroup = mainremote.getObject("blakk.volume.group");
	TimerCover = infoGroup.getObject("blakk.info.cover");
	TickerCover = TracktextsGroup.getObject("blakk.tracktext.cover");
	TogglesCover = TogglesGroup.getObject("blakk.toggles.cover");
	
//	AlbumArt = AlbumArtGroup.getObject("blakk.volume.group");
	AlbumShiftTimer = new timer;
	AlbumShiftTimer.setDelay(500);
	AlbumShiftBackTimer = new timer;
	AlbumShiftBackTimer.setDelay(500);
	BigArt = 0;	
}

System.onScriptUnloading(){
	delete AlbumShiftTimer;
	delete AlbumShiftBackTimer;
}


AlbumArt.onRightButtonDown (int x, int y)
{
	popupmenu p = new popupmenu;

	p.addCommand("Get Album Art", 1, 0, 0);
	p.addCommand("Refresh Album Art", 2, 0, 0);
	p.addCommand("Open Folder", 3, 0, 0);

	int result = p.popatmouse();
	delete p;

	if (result == 1)
	{
		if (system.getAlbumArt(system.getPlayItemString()) > 0)
		{
			AlbumArt.setXmlParam("notfoundimage", getXmlParam("notfoundimage")); // a nesty refresh - isn't it?
		}
	}
	else if (result == 2)
	{
		AlbumArt.setXmlParam("notfoundimage", getXmlParam("notfoundimage")); // a nesty refresh - isn't it?
	}
	else if (result == 3)
	{
		System.navigateUrl(system.getPath(system.getPlayItemString()));
	}

}

/* Sorry.... needed the doubleclick for my shifting

AlbumArt.onLeftButtonDblClk (int x, int y)
{
	System.navigateUrl(system.getPath(system.getPlayItemString()));
}
*/



// Albumart Shifting
AlbumArt.onLeftButtonDblClk (int x, int y)
	{
	if (!BigArt) { 
	 	TimerCover.setTargetA(255);
		TickerCover.setTargetA(255);
		TogglesCover.setTargetA(255);
		
		TimerCover.setTargetSpeed(0.5);
		TickerCover.setTargetSpeed(0.5);
		TogglesCover.setTargetSpeed(0.5);
		
		TimerCover.gotoTarget();
		TickerCover.gotoTarget();
		TogglesCover.gotoTarget();
		AlbumShiftTimer.start();
		
		TimerCover.setXMLParam("ghost", "0");
		TickerCover.setXMLParam("ghost", "0");
		TogglesCover.setXMLParam("ghost", "0");

	} else { 
		SeekerGroup.setTargetY(0);
		VolumeGroup.setTargetY(0);
		AlbumArtGroup.setTargetW(50);
		AlbumArtGroup.setTargetH(50);
		
		SeekerGroup.setTargetSpeed(0.5);
		VolumeGroup.setTargetSpeed(0.5);
		AlbumArtGroup.setTargetSpeed(0.5);
		
		SeekerGroup.gotoTarget();
		VolumeGroup.gotoTarget();
		AlbumArtGroup.gotoTarget();
		AlbumShiftBackTimer.start();
	}
}
		
		
AlbumShiftTimer.onTimer()
	{
		SeekerGroup.setTargetY(56);
		VolumeGroup.setTargetY(99);
		AlbumArtGroup.setTargetW(144);
		AlbumArtGroup.setTargetH(144);
		
		SeekerGroup.setTargetSpeed(0.5);
		VolumeGroup.setTargetSpeed(0.5);
		AlbumArtGroup.setTargetSpeed(0.5);
		
		SeekerGroup.gotoTarget();
		VolumeGroup.gotoTarget();
		AlbumArtGroup.gotoTarget();
		
		BigArt = 1;	
		stop();
}	
		

AlbumShiftBackTimer.onTimer()
	{
	 	TimerCover.setTargetA(0);
		TickerCover.setTargetA(0);
		TogglesCover.setTargetA(0);
		
		TimerCover.setTargetSpeed(0.5);
		TickerCover.setTargetSpeed(0.5);
		TogglesCover.setTargetSpeed(0.5);
		
		TimerCover.gotoTarget();
		TickerCover.gotoTarget();
		TogglesCover.gotoTarget();
		
		BigArt = 0;
		stop();
				
		TimerCover.setXMLParam("ghost", "1");
		TickerCover.setXMLParam("ghost", "1");
		TogglesCover.setXMLParam("ghost", "1");		
}
		
		
		
