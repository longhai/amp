/*____________________________
 BLAKK - Boombox EQ Controls
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/


#include <lib/std.mi>

Function setEqOnLayer(int eqValue, layer eqName);
Class Layer HintLayer;
Global Map EQMap;
Global int isEQ;
Global HintLayer eq0, eq1, eq2, eq3, eq4, eq5, eq6, eq7, eq8, eq9, eq10, eqpre;

Class GuiObject HintObject;
Global HintObject PresetBton, PresetTXT, AutoBtonTXT, OnOffTXT, OnOffLED, CrossfadeStateIcon,RepeatBtnFAKE, ShuffleIcon;

Class Button HintButton;
Global HintButton AutoBton, EqOnOff, CrossfadeOnOff;

Function setTempText3(String txt);
Function setTempText4(String txt, String txt2);
Function emptyTempText3();
Function emptyTempText4();
Function emptyTempText5();
Function setTempText5(String txt3);
Global Text Songticker;
Global Timer Songtickertimer3;

Global Togglebutton RepeatBtn, ShuffleBtn, BBoxXbass, RemoteXbass, StickXbass;
Global Boolean xbassStatus;
Global Layout mainBbox;
Global Slider eq0_SLDR, eq1_SLDR, eq2_SLDR, eq3_SLDR, eq4_SLDR, eq5_SLDR, eq6_SLDR, eq7_SLDR, eq8_SLDR, eq9_SLDR, eqpre_SLDR;

Global Text ArtistText, TitleText;
Global Timer ArtistTickertimer2;

Global Timer Sticktickertimer2;
Global Text StickTicker2;

System.onScriptLoaded() {
 
 Group eqgroup = getContainer("eq").getLayout("normal").getObject("blakk.eq.group.sliders");

  eqpre = eqgroup.getObject("eqpre");
  eq0 = eqgroup.getObject("eq0");
  eq1 = eqgroup.getObject("eq1");
  eq2 = eqgroup.getObject("eq2");
  eq3 = eqgroup.getObject("eq3");
  eq4 = eqgroup.getObject("eq4");
  eq5 = eqgroup.getObject("eq5");
  eq6 = eqgroup.getObject("eq6");
  eq7 = eqgroup.getObject("eq7");
  eq8 = eqgroup.getObject("eq8");
  eq9 = eqgroup.getObject("eq9");

  EQMap = new Map;
  EQMap.loadMap("player.eq-map");

  setEqOnLayer(- (System.getEqPreamp()) + 128, eqpre);
  setEqOnLayer(- (System.getEqBand(1)) + 128, eq0);
  setEqOnLayer(- (System.getEqBand(2)) + 128, eq1);
  setEqOnLayer(- (System.getEqBand(3)) + 128, eq2);
  setEqOnLayer(- (System.getEqBand(4)) + 128, eq3);
  setEqOnLayer(- (System.getEqBand(5)) + 128, eq4);
  setEqOnLayer(- (System.getEqBand(6)) + 128, eq5);
  setEqOnLayer(- (System.getEqBand(7)) + 128, eq6);
  setEqOnLayer(- (System.getEqBand(8)) + 128, eq7);
  setEqOnLayer(- (System.getEqBand(9)) + 128, eq8);
  setEqOnLayer(- (System.getEqBand(10)) + 128, eq9);

  Layout eqnorm = getContainer("eq").getLayout("normal");
  PresetTXT = eqnorm.getObject("blakk.eq.preset-text");
  PresetBton = eqnorm.getObject("blakk.eq.preset");
 
  AutoBton = eqnorm.getObject("blakk.eq.auto");
  AutoBtonTXT = eqnorm.getObject("blakk.eq.auto-text");
  if ( AutoBton.getActivated()==1 ) AutoBtonTXT.setXMLParam("image", "player.eq-auto-text-on" );
 
  OnOffTXT = eqnorm.getObject("blakk.eq.state-text");
  OnOffLED = eqnorm.getObject("blakk.eq.state-onoff");
  EqOnOff = eqnorm.getObject("blakk.eq.onoff");

  if ( system.getEQ() ) 
	{
	OnOffLED.setXMLParam("image", "player.eq-state-icon-on" ); 
	OnOffTXT.setXMLParam("image", "player.eq-state-text-on" );
	}
  CrossfadeOnOff = eqnorm.getObject("blakk.Crossfade");
  CrossfadeStateIcon = eqnorm.getObject("blakk.crossfade-icon");
	
	int crsfde_on;
	crsfde_on=CrossfadeOnOff.getActivated();
	CrossfadeOnOff.setActivated(crsfde_on);
		if (crsfde_on==1) CrossfadeStateIcon.setXMLParam("image", "player.eq-fade-state-icon-on" );
		if (crsfde_on==0) CrossfadeStateIcon.setXMLParam("image", "player.eq-fade-state-icon-off" );

	Songtickertimer3 = new Timer;
 	Songtickertimer3.setDelay(1000);
	
	Songticker = getContainer("main").getLayout("boombox").findObject("Songticker");
	RepeatBtn = eqnorm.getObject("blakk.repeat");
	RepeatBtnFAKE = eqnorm.getObject("blakk.repeat-fakeBGbutton"); 
	
	int v = RepeatBtn.getCurCfgVal();
		if (v == 0)
			{
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-off" );
		}
        else if (v > 0)
			{
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-on" );
		}
        else if (v < 0)
			{
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-on" );
		}
	ShuffleBtn = eqnorm.getObject("blakk.shuffle");
	ShuffleIcon = eqnorm.getObject("blakk.shuffle-status");

	int shuf_on=ShuffleBtn.getActivated();
	if (shuf_on == 1) ShuffleIcon.setXMLParam("image", "player.eq-shuffle-status-on");  else ShuffleIcon.setXMLParam("image", "player.eq-shuffle-status-off");

	mainBbox = getContainer("main").getLayout("boombox");
	BBoxXbass = mainBbox.getObject("blakk.bb.XBS");	

	Group RemoteToggleGroup = getContainer("main").getLayout("remote").getObject("blakk.remote-toggles.group");	
	RemoteXbass = RemoteToggleGroup.getObject("blakk.remote.XBS");
	
	StickXbass = getContainer("main").getLayout("stick").getObject("blakk.stick.XBS");

	xbassStatus = getPrivateInt("BLAKK", "Xbass", 0);
    BBoxXbass.setActivated(xbassStatus);
	RemoteXbass.setActivated(xbassStatus);
	StickXbass.setActivated(xbassStatus);	
	
	eqpre_SLDR = eqgroup.getObject("pre");
	eq0_SLDR = eqgroup.getObject("0");
	eq1_SLDR = eqgroup.getObject("1");
	eq2_SLDR = eqgroup.getObject("2");
	eq3_SLDR = eqgroup.getObject("3");
	eq4_SLDR = eqgroup.getObject("4");
	eq5_SLDR = eqgroup.getObject("5");
	eq6_SLDR = eqgroup.getObject("6");
	eq7_SLDR = eqgroup.getObject("7");
	eq8_SLDR = eqgroup.getObject("8");
	eq9_SLDR = eqgroup.getObject("9");
  
  	Layout mainremote = getContainer("main").getLayout("remote");
  	Group TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	ArtistText = TracktextsGroup.getObject("ArtistText");
	TitleText = TracktextsGroup.getObject("TitleText");

	ArtistTickertimer2 = new Timer;
 	ArtistTickertimer2.setDelay(1000);
 
	Sticktickertimer2 = new Timer;
 	Sticktickertimer2.setDelay(1000);
	
	StickTicker2 = getContainer("main").getLayout("stick").getObject("Songticker");	
}

System.onScriptUnloading() {
	delete Songtickertimer3;
	delete ArtistTickertimer2;
    setPrivateInt("BLAKK", "Xbass", xbassStatus);

}

// EQ slider map layers (uses physical sliders, maps only for show)
System.onEqPreampChanged(int newvalue) {
	setEqOnLayer(- (newvalue) + 128, eqpre);
	if (newvalue > 0) string p = "+";  else p = "";
	setTempText3("EQ Preamp: " + p + integerToString(newvalue));	
}

System.onEqBandChanged(int band, int newvalue) {
	if (band == 0)
		{
		setEqOnLayer(- (newvalue) + 128, eq0);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 60 Hz: " + p + integerToString(newvalue));	
	}	
	if (band == 1)
		{
		setEqOnLayer(- (newvalue) + 128, eq1);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 170 Hz: " + p + integerToString(newvalue));	
	}	
	if (band == 2)
		{	
		setEqOnLayer(- (newvalue) + 128, eq2);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 310 Hz: " + p + integerToString(newvalue));	
	}	
	if (band == 3)
		{
		setEqOnLayer(- (newvalue) + 128, eq3);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 600 Hz: " + p + integerToString(newvalue));	
	}	
	if (band == 4)
		{
		setEqOnLayer(- (newvalue) + 128, eq4);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 1 KHz: " + p + integerToString(newvalue));	
	}
	if (band == 5) 
		{
		setEqOnLayer(- (newvalue) + 128, eq5);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 3 KHz: " + p + integerToString(newvalue));	

	}
	if (band == 6)
		{
		setEqOnLayer(- (newvalue) + 128, eq6);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 6 KHz: " + p + integerToString(newvalue));	
	}
	if (band == 7)
			{
		setEqOnLayer(- (newvalue) + 128, eq7);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 12 KHz: " + p + integerToString(newvalue));	
	}	
	if (band == 8)
		{
		setEqOnLayer(- (newvalue) + 128, eq8);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 14 KHz: " + p + integerToString(newvalue));	
	}	
	if (band == 9)
		{
		setEqOnLayer(- (newvalue) + 128, eq9);
		if (newvalue > 0) string p = "+";  else p = "";
		setTempText3("EQ Freq. 16 KHz: " + p + integerToString(newvalue));	
	}
}

setEqOnLayer(int eqValue, layer eqName) {
	Region r = new Region;  
	r.loadFromMap(EQMap, eqValue, 0);
	eqName.setRegion(r);
  
	delete r;
}

//Preset, Auto buttons, OnOff & crossfade buttons
PresetBton.onLeftButtonDown(int x, int y){
	PresetTXT.setXMLParam("y", "49");
	setTempText3("Load/Save Audio Presets");
	setTempText4("Audio Presets:", "Load, Save or Delete");
	setTempText5("Load/Save Audio Presets");	
}

PresetBton.onLeftButtonUp(int x, int y){
	PresetTXT.setXMLParam("y", "48");
}	
	
AutoBton.onActivate(int act) {
	if (act==1) 
		{	AutoBtonTXT.setXMLParam("image", "player.eq-auto-text-on" ); 
			setTempText3("Auto Processing: ON");
			setTempText4("Auto Processing:", "ON");
			setTempText5("Auto Processing: ON");				
	}	
	if (act==0) 
		{	AutoBtonTXT.setXMLParam("image", "player.eq-auto-text" ); 
			setTempText3("Auto Processing: OFF");
			setTempText4("Auto Processing:", "OFF");
			setTempText5("Auto Processing: OFF");				
	}
}

AutoBton.onLeftButtonDown(int x, int y) {
	AutoBtonTXT.setXMLParam("y", "49");
}	

AutoBton.onLeftButtonUp(int x, int y) {
	AutoBtonTXT.setXMLParam("y", "48");
}

EqOnOff.onLeftButtonDown(int x, int y) {
	OnOffTXT.setXMLParam("y", "50");
	OnOffLED.setXMLParam("y", "47");
}

EqOnOff.onLeftButtonUp(int x, int y) {
	OnOffTXT.setXMLParam("y", "49");
	OnOffLED.setXMLParam("y", "46");
}	
	
EqOnOff.onActivate(int act) {
	if (act==1) 
		{ OnOffLED.setXMLParam("image", "player.eq-state-icon-on" );
			OnOffTXT.setXMLParam("image", "player.eq-state-text-on" );
		  	setTempText3("Equalizer now: ON");
			setTempText4("Equalizer now:", "ON");
			setTempText5("Equalizer now: ON");				
		}
	if (act==0)
		{ OnOffLED.setXMLParam("image", "player.eq-state-icon-off" );
			OnOffTXT.setXMLParam("image", "player.eq-state-text" );
			setTempText3("Equalizer now: OFF");
			setTempText4("Equalizer now:", "OFF");
			setTempText5("Equalizer now: OFF");				
		}
}

CrossfadeOnOff.onLeftButtonDown(int x, int y) {
	CrossfadeStateIcon.setXMLParam("y", "48");
}

CrossfadeOnOff.onLeftButtonUp(int x, int y) {
	CrossfadeStateIcon.setXMLParam("y", "47");
}
	
CrossfadeOnOff.onActivate(int onOff) {
	if (onOff==1) 
		{ CrossfadeStateIcon.setXMLParam("image", "player.eq-fade-state-icon-on" );
		  setTempText3("Crossfading: ON");
		  setTempText4("Crossfading:", "ON");
		  setTempText5("Crossfading: ON");
	}
	if (onOff==0)
		{ CrossfadeStateIcon.setXMLParam("image", "player.eq-fade-state-icon-off" );
		  setTempText3("Crossfading: OFF");
		  setTempText4("Crossfading:", "OFF");
		  setTempText5("Crossfading: OFF");		  
	}
}

// Temp text to handle
Songtickertimer3.onTimer() {
	SongTicker.setText("");
	stop();
}

ArtistTickertimer2.onTimer() {
	TitleText.setText(System.getPlayItemMetaDataString("title"));
	ArtistText.setText(System.getPlayItemMetaDataString("artist"));
	stop();
}

Sticktickertimer2.onTimer() {
	StickTicker2.setText("");
	stop();
}

setTempText3(String txt) {
	Songtickertimer3.stop();
	Songticker.setText(txt);
	Songtickertimer3.start();
}

emptyTempText3() {
	Songticker.setText("");
	Songtickertimer3.stop();
}

setTempText4(String txt, String txt2) {
	ArtistTickertimer2.stop();
  	ArtistText.setText(txt);
	TitleText.setText(txt2);
  	ArtistTickertimer2.start();
}

emptyTempText4() {
	TitleText.setText(System.getPlayItemMetaDataString("title"));
	ArtistText.setText(System.getPlayItemMetaDataString("artist"));
	ArtistTickertimer2.stop();
}

setTempText5(String txt3) {
	Sticktickertimer2.stop();
	StickTicker2.setText(txt3);
	Sticktickertimer2.start();
}

emptyTempText5() {
	StickTicker2.setText("");
	Sticktickertimer2.stop();
}	

// Repeart button temp text
RepeatBtn.onToggle(boolean on) {
		int v = getCurCfgVal();
		if (v == 0)
			{
			setTempText3("Repeat: OFF");
			setTempText4("Repeat:", "OFF");
			setTempText5("Repeat: OFF");
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-off" );
		}
        else if (v > 0)
			{
			setTempText3("Repeat: ALL TRACKS");
			setTempText4("Repeat:", "ALL TRACKS");
			setTempText5("Repeat: ALL TRACKS");
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-on" );
		}
        else if (v < 0)
			{
			setTempText3("Repeat: ONE TRACK");
			setTempText4("Repeat:", "ONE TRACK");
			setTempText5("Repeat: ONE TRACK");
			RepeatBtnFAKE.setXMLParam("image", "player.eq-fade-state-on" );
		}
}

RepeatBtn.onLeftButtonDown(int x, int y) {
	RepeatBtn.setXMLParam("y", "42" );
}

RepeatBtn.onLeftButtonUp(int x, int y) {
	RepeatBtn.setXMLParam("y", "41" );
}

ShuffleBtn.onLeftButtonDown(int x, int y) {
	ShuffleIcon.setXMLParam("y", "42" );
}

ShuffleBtn.onLeftButtonUp(int x, int y) {
	ShuffleIcon.setXMLParam("y", "41" );
}

ShuffleBtn.onToggle(boolean on) {
	if (on) {
		setTempText3("Playlist Shuffling: ON");
		setTempText4("Playlist Shuffling:", "ON");
		setTempText5("Playlist Shuffling: ON");
		ShuffleIcon.setXMLParam("image", "player.eq-shuffle-status-on");
	}
	else {
		setTempText3("Playlist Shuffling: OFF");
		setTempText4("Playlist Shuffling:", "OFF");
		setTempText5("Playlist Shuffling: OFF");
		ShuffleIcon.setXMLParam("image", "player.eq-shuffle-status-off");
	}
}

//X-BASS button
BBoxXbass.onLeftButtonUp(int x, int y) {
	if (xbassStatus == 0) {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() + 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() + 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() + 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() + 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() + 5));
		xbassStatus = 1;
		setTempText3("X-BASS: ON");	
		StickXbass.setActivated(xbassStatus);
		RemoteXbass.setActivated(xbassStatus);	
	} else {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() - 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() - 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() - 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() - 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() - 5));
		xbassStatus = 0;
		setTempText3("X-BASS: OFF");
		StickXbass.setActivated(xbassStatus);
		RemoteXbass.setActivated(xbassStatus);	
	}
}

RemoteXbass.onLeftButtonUp(int x, int y) {
	if (xbassStatus == 0) {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() + 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() + 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() + 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() + 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() + 5));
		xbassStatus = 1;
		setTempText4("X-BASS:", "ON");
		StickXbass.setActivated(xbassStatus);
		BBoxXbass.setActivated(xbassStatus);
	} else {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() - 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() - 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() - 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() - 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() - 5));
		xbassStatus = 0;
		setTempText4("X-BASS:", "OFF");
		StickXbass.setActivated(xbassStatus);
		BBoxXbass.setActivated(xbassStatus);
	}
}

StickXbass.onLeftButtonUp(int x, int y) {
	if (xbassStatus == 0) {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() + 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() + 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() + 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() + 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() + 5));
		xbassStatus = 1;
		setTempText5("X-BASS: ON");
		RemoteXbass.setActivated(xbassStatus);
		BBoxXbass.setActivated(xbassStatus);
	} else {
		eqpre_SLDR.setPosition((eqpre_SLDR.getPosition() - 12));
		eq0_SLDR.setPosition((eq0_SLDR.getPosition() - 38));
		eq1_SLDR.setPosition((eq1_SLDR.getPosition() - 24));
		eq2_SLDR.setPosition((eq2_SLDR.getPosition() - 12));
		eq3_SLDR.setPosition((eq3_SLDR.getPosition() - 5));
		xbassStatus = 0;
		setTempText5("X-BASS: OFF");
		RemoteXbass.setActivated(xbassStatus);
		BBoxXbass.setActivated(xbassStatus);
	}
}