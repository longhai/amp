/*---------------------------------------------------
 BLAKK - MiniVis AVS Shifting (Remote Player Mode)
 Design by: iamvica.com
 Script kittying by: eXaltic.com
---------------------------------------------------*/

#include <lib/std.mi>


Global Layout mainremote;
Global Group infoGroup, TracktextsGroup, SeekerGroup, AlbumArtGroup, VolumeGroup, TogglesGroup, VisGroup,VisGroupGroup ; 
Global layer TimerCover, TickerCover, TogglesCover, AlbumartCover;
Global Timer ShiftSlidersTimer, ShowVisTimer, ShiftBackSliderTimer, ReshowDisplayTimer;
Global Boolean isMiniAVS;
Global Togglebutton AVSToggle, Vis_random;
Global Button Vis_config, Vis_previous, Vis_next, Vis_close;

System.onScriptLoaded ()
{
	mainremote = getContainer("main").getLayout("remote");
	infoGroup = mainremote.getObject("blakk.infobox.group");
	SeekerGroup = mainremote.getObject("blakk.seek.group");
	TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	
	TogglesGroup = mainremote.getObject("blakk.remote-toggles.group");		
	AlbumArtGroup = mainremote.getObject("blakk.remote-albumart.group");
	VolumeGroup = mainremote.getObject("blakk.volume.group");
	VisGroup = mainremote.getObject("blakk.remote-avsgroup.group");
	
	TimerCover = infoGroup.getObject("blakk.info.cover");
	TickerCover = TracktextsGroup.getObject("blakk.tracktext.cover");
	TogglesCover = TogglesGroup.getObject("blakk.toggles.cover");
	AlbumartCover = AlbumArtGroup.getObject("blakk.remote-albumart-cover");
	AVSToggle = TogglesGroup.getObject("blakk.remote-toggle-avs");
	VisGroupGroup = VisGroup.getObject("blakk.component.vis");
	Vis_config = VisGroup.getObject("blakk.avs-vis-config");
	Vis_previous = VisGroup.getObject("blakk.avs-vis-prev");
	Vis_next = VisGroup.getObject("blakk.avs-vis-next");
	Vis_random = VisGroup.getObject("blakk.avs-vis-random");
	Vis_close = VisGroup.getObject("blakk.avs-vis-close");
	
	
	ShiftSlidersTimer = new timer;
	ShiftSlidersTimer.setDelay(500);
	ShowVisTimer = new timer;
	ShowVisTimer.setDelay(500);
	
	int isMiniAVS;
	isMiniAVS = 0;
	AVSToggle.setActivated(isMiniAVS);
	
	ShiftBackSliderTimer = new timer;
	ShiftBackSliderTimer.setDelay(500);
	ReshowDisplayTimer = new timer;
	ReshowDisplayTimer.setDelay(500);

	VisGroup.setXMLParam("x", "161");
	Vis_config.hide();
	Vis_previous.hide();
	Vis_next.hide();
	Vis_random.hide();
	Vis_close.hide();
	VisGroupGroup.hide();
}

System.onScriptUnloading(){
	delete ShiftSlidersTimer;
	delete ShowVisTimer;
	delete ShiftBackSliderTimer;
	delete ReshowDisplayTimer;
}


// Albumart Shifting
AVSToggle.onLeftClick ()
	{
	 	TimerCover.setTargetA(255);
		TickerCover.setTargetA(255);
		TogglesCover.setTargetA(255);
		AlbumartCover.setTargetA(255);
		
		TimerCover.setTargetSpeed(0.5);
		TickerCover.setTargetSpeed(0.5);
		TogglesCover.setTargetSpeed(0.5);
		AlbumartCover.setTargetSpeed(0.5);
		
		TimerCover.gotoTarget();
		TickerCover.gotoTarget();
		TogglesCover.gotoTarget();
		AlbumartCover.gotoTarget();
		ShiftSlidersTimer.start();
		
	 	TimerCover.setXMLParam("ghost", "0");
		TickerCover.setXMLParam("ghost", "0");
		TogglesCover.setXMLParam("ghost", "0");
		AlbumartCover.setXMLParam("ghost", "0");	
}


Vis_close.onLeftClick ()
	{ 
		Vis_config.setTargetX(10);
		Vis_previous.setTargetX(10);
		Vis_random.setTargetX(10);
		Vis_next.setTargetX(10);
		Vis_close.setTargetX(10);
	
		Vis_config.setTargetSpeed(0.5);
		Vis_previous.setTargetSpeed(0.5);
		Vis_random.setTargetSpeed(0.5);
		Vis_next.setTargetSpeed(0.5);
		Vis_close.setTargetSpeed(0.5);

		Vis_config.gotoTarget();
		Vis_previous.gotoTarget();
		Vis_random.gotoTarget();
		Vis_next.gotoTarget();
		Vis_close.gotoTarget();	
	
		isMiniAVS = 0;
		AVSToggle.setActivated(isMiniAVS);
		
		ShiftBackSliderTimer.start();
}
		
		
ShiftSlidersTimer.onTimer()
	{
		SeekerGroup.setTargetY(56);
		VolumeGroup.setTargetY(99);
		SeekerGroup.setTargetSpeed(0.5);
		VolumeGroup.setTargetSpeed(0.5);
		SeekerGroup.gotoTarget();
		VolumeGroup.gotoTarget();
		stop();
		ShowVisTimer.start();
}	
	
		
ShowVisTimer.onTimer()
	{	
	VisGroup.setXMLParam("x", "0");

	Vis_config.show();
	Vis_previous.show();
	Vis_random.show();
	Vis_next.show();
	Vis_close.show();
	
	Vis_config.setTargetX(10);
	Vis_previous.setTargetX(34);
	Vis_random.setTargetX(58);
	Vis_next.setTargetX(82);
	Vis_close.setTargetX(129);
	
	Vis_config.setTargetSpeed(0.5);
	Vis_previous.setTargetSpeed(0.5);
	Vis_random.setTargetSpeed(0.5);
	Vis_next.setTargetSpeed(0.5);
	Vis_close.setTargetSpeed(0.5);

	Vis_config.gotoTarget();
	Vis_previous.gotoTarget();
	Vis_random.gotoTarget();
	Vis_next.gotoTarget();
	Vis_close.gotoTarget();	
	
	VisGroupGroup.show();
	stop();
}

		
ShiftBackSliderTimer.onTimer()	
{
		Vis_config.hide();
		Vis_previous.hide();
		Vis_next.hide();
		Vis_random.hide();
		Vis_close.hide();
		VisGroupGroup.hide();
		VisGroup.setXMLParam("x", "161");

		SeekerGroup.setTargetY(0);
		VolumeGroup.setTargetY(0);
		
		SeekerGroup.setTargetSpeed(0.5);
		VolumeGroup.setTargetSpeed(0.5);
		
		SeekerGroup.gotoTarget();
		VolumeGroup.gotoTarget();
		stop();
		ReshowDisplayTimer.start();
}	

		
ReshowDisplayTimer.onTimer()
	{
	 	TimerCover.setTargetA(0);
		TickerCover.setTargetA(0);
		TogglesCover.setTargetA(0);
		AlbumartCover.setTargetA(0);
		
		TimerCover.setTargetSpeed(0.5);
		TickerCover.setTargetSpeed(0.5);
		TogglesCover.setTargetSpeed(0.5);
		AlbumartCover.setTargetSpeed(0.5);
		
		TimerCover.gotoTarget();
		TickerCover.gotoTarget();
		TogglesCover.gotoTarget();
		AlbumartCover.gotoTarget();
		
		TimerCover.setXMLParam("ghost", "1");
		TickerCover.setXMLParam("ghost", "1");
		TogglesCover.setXMLParam("ghost", "1");
		AlbumartCover.setXMLParam("ghost", "1");
		
		stop();
}