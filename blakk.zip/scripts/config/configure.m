/*____________________________
 BLAKK - Configure Window
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/

#include <lib/std.mi>
Function Config();
Function Modedetect();

Global Text StickTicker, ArtistText, TitleText, bboxsongticker, mainsongticker;
Global Button checboxTickerOn, checboxBboxOn;
Global Button mainswitch, bboxswitch, stickswitch, hardwaregeekslink, vicalink;
Global Group TracktextsGroup;
Global String stringDefaultModes;
Global Button iamvicalink, exalticlink, danlink;

System.onScriptLoaded() {
	Layout mainremote = System.getContainer("main").getLayout("remote");
	Layout mainbbox = System.getContainer("main").getLayout("boombox");
	Layout mainstick = System.getContainer("main").getLayout("stick");
	Layout confignorm = System.getContainer("configure").getLayout("normal");
	Layout configabout = System.getContainer("configure").getLayout("about");

	GuiObject titleboxAboutBLAKK = configabout.getObject("About-BLAKK");
	GuiObject titleboxCPUsaving = confignorm.getObject("CPU-saving");

	Group AboutGroup = titleboxAboutBLAKK.findObject("about.group");
	Group CPUsavingGroup = titleboxCPUsaving.findObject("cpusaving.group");

	iamvicalink = AboutGroup.findObject("about.iamvica.com");
	exalticlink = AboutGroup.findObject("about.exaltic.com");
	danlink = AboutGroup.findObject("about.dan");
	
	checboxTickerOn = CPUsavingGroup.findObject("SontickerScrolling");
	checboxBboxOn = CPUsavingGroup.findObject("BoomBoxAnim");
	
	bboxsongticker = getContainer("main").getLayout("boombox").findObject("Songticker");
	TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	ArtistText = TracktextsGroup.getObject("ArtistText");
	TitleText = TracktextsGroup.getObject("TitleText");
	StickTicker = mainstick.getObject("Songticker");
	
	mainswitch = mainremote.getObject("blakk-remote-switch-bton");
	bboxswitch = mainbbox.getObject("blakk-switch-bton");
	stickswitch = mainstick.getObject("blakk-stick-switch-bton");

	Config();
}

Config() {
	checboxTickerOn.onActivate(System.getPrivateInt("BLAKK", "SontickerScrolling", 1));
	checboxBboxOn.onActivate(System.getPrivateInt("BLAKK", "BoomBoxAnim", 1));
}

checboxTickerOn.onActivate(int activated) {
	bboxsongticker.setXmlParam("ticker", System.integerToString(activated));
	StickTicker.setXmlParam("ticker", System.integerToString(activated));
	TitleText.setXmlParam("ticker", System.integerToString(activated));
	ArtistText.setXmlParam("ticker", System.integerToString(activated));
}  

checboxBboxOn.onActivate(int activated) {
	Layer LeftSpeaker = System.getContainer("main").getLayout("boombox").getObject("LeftSpeaker");
	Layer RightSpeaker = System.getContainer("main").getLayout("boombox").getObject("RightSpeaker");
	LeftSpeaker.hide();
	RightSpeaker.hide();
	if(activated) {
		LeftSpeaker.show();
		RightSpeaker.show();
	}
	else {
		LeftSpeaker.hide();
		RightSpeaker.hide();
	}
}  

iamvicalink.onLeftclick() {System.navigateUrl("http://www.iamvica.com"); }
exalticlink.onLeftclick() {System.navigateUrl("http://exaltic.com/");} 
danlink.onLeftclick() {System.navigateUrl("http://www.d3-designz.co.uk");} 

Modedetect() {
	stringDefaultModes = "";
	stringDefaultModes = System.getPrivateString("BLAKK", "MainwindowModes", stringDefaultModes);
}

mainswitch.onLeftClick() {
	ModeDetect();
	Container MainCntr = System.getContainer("main");
	if (stringDefaultModes == "Remote and Stick Modes") {
		MainCntr.switchToLayout("stick");		
	} else {
		MainCntr.switchToLayout("boombox");		
	}
}

bboxswitch.onLeftClick() {
	ModeDetect();
	Container MainCntr = System.getContainer("main");
	if (stringDefaultModes == "Remote and Boombox Modes") {
		MainCntr.switchToLayout("remote");		
	} else {
		MainCntr.switchToLayout("stick");		
	}

}

stickswitch.onLeftClick() {
	ModeDetect();
	Container MainCntr = System.getContainer("main");
	if (stringDefaultModes == "Boombox and Stick Modes") {
		MainCntr.switchToLayout("boombox");		
	} else {
		MainCntr.switchToLayout("remote");		
	}
}
