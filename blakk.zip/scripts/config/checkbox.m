#include "../../../../lib/std.mi"
   
Global Text textBox;
Global Button buttonCheckBox;
Global String stringItem = "";
Global String stringSection = "";
Global int intDefaultValue = 999;

System.onScriptLoaded() {
	textBox = getScriptGroup().getObject("checkbox.text");
	buttonCheckBox = getScriptGroup().getObject("checkbox.toggle");
}

System.onSetXuiParam(String stringParam, String stringValue) {
	if (strlower(stringParam) == "usetext") textBox.setText(stringValue);
	if (strlower(stringParam) == "privateintsection") stringSection = stringValue;
	if (strlower(stringParam) == "privateintitem") stringItem = stringValue;
	if (strlower(stringParam) == "default") intDefaultValue = System.stringToInteger(stringValue);
	if (stringItem != "" && stringSection != "" && intDefaultValue != 999) buttonCheckBox.setActivated(System.getPrivateInt(stringSection, stringItem, intDefaultValue));
}

buttonCheckBox.onLeftClick() {
	buttonCheckBox.setActivated(!buttonCheckBox.getActivated());
}

textBox.onLeftButtonUp(Int intPosX, Int intPosY) {
	buttonCheckBox.setActivated(!buttonCheckBox.getActivated());
}

buttonCheckBox.onActivate(Int intActivated) {
	System.setPrivateInt(stringSection, stringItem, intActivated);
}