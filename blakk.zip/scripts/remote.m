/*____________________________
 BLAKK - Remote Player Mode
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/

#include <lib/std.mi>

Function string tokenizeSongInfo(String tkn, String sinfo);
Global GuiObject StereoTxt, MonoTxt, PlayStatusIcon;
Global Layout mainremote;
Global Text bitrateText, infoHiddenText, FrequencyText;
Global Timer songInfoTimer;
Global String SongInfoString;
Global Group infoGroup;

Global Text ArtistText, TitleText, hiddenTicker;
Global Group TracktextsGroup;

Function setTempText(String txt, String txt2);
Function emptyTempText();
Function updateSeeker(int x, int y, map remoteSeekMap, layer remoteSeek, text ArtistText, text TitleText);
Global Text ArtistTicker;
Global Timer ArtistTickertimer;
Global Group SeekerGroup;
Global Int seeking, now;
Global String Hitten;
Global slider hidremoteseek;
Global layer remoteSeek,remoteSeekFull;
Global map remoteSeekMap;
Global region remoteSeekRegion;

Global Button remoteStop, remoteEject, remotePause, remotePlay;



System.onScriptLoaded() {
 
	mainremote = getContainer("main").getLayout("remote");
	infoGroup = mainremote.getObject("blakk.infobox.group");
	
	StereoTxt = infoGroup.getObject("blakk-stereo");
	MonoTxt = infoGroup.getObject("blakk-mono");

    infoHiddenText = infoGroup.getObject("hiddeninfoTEXT");
    bitrateText = infoGroup.getObject("blakk.bitrate-text");
    FrequencyText = infoGroup.getObject("blakk.freq-text");
	StereoTxt.hide();
	MonoTxt.hide();
	songInfoTimer = new Timer;
	songInfoTimer.setDelay(1000);
	if (getLeftVUMeter()!=null) songInfoTimer.start();

    PlayStatusIcon = infoGroup.getObject("blakk-playstatus");	
	
	int sysStat;
	sysStat = System.getStatus();
	if (sysStat==-1) {
		PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-pause");
		songInfoTimer.start();
		}
	if (sysStat==0) {
		PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-stop");
		}
	if (sysStat==1) {
		PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-play");
		songInfoTimer.start();
		}

	TracktextsGroup = mainremote.getObject("blakk.tracktexts.group");
	ArtistText = TracktextsGroup.getObject("ArtistText");
	TitleText = TracktextsGroup.getObject("TitleText");
	hiddenTicker = TracktextsGroup.getObject("hiddenTicker");

	TitleText.setText(System.getPlayItemMetaDataString("title"));
	ArtistText.setText(System.getPlayItemMetaDataString("artist"));

	SeekerGroup = mainremote.getObject("blakk.seek.group");
 	hidremoteseek = SeekerGroup.getObject("blakk.remote.hidseek");
	remoteSeek = SeekerGroup.getObject("blakk.remote.seekempty");
 	remoteSeekFull = SeekerGroup.getObject("blakk.remote.seekfull");
 	remoteSeekRegion = New Region;
 	remoteSeekRegion.loadfrombitmap("player.remote-seek-region");
 	remoteSeek.setregion(remoteSeekRegion);
 	remoteSeekMap = New Map;
 	remoteSeekMap.loadmap("player.remote-seek-map");
 	remoteSeekFull.hide();
	
	ArtistTickertimer = new Timer;
 	ArtistTickertimer.setDelay(1000);
	
	remoteStop = mainremote.getObject("blakk.remote-stop");
	remoteEject = mainremote.getObject("blakk.remote-eject");
	remotePause = mainremote.getObject("blakk.remote-pause"); 
	remotePlay = mainremote.getObject("blakk.remote-play");

	remotePlay.hide(); // Yes, hide all switchable buttons on start
	remotePause.hide();
	remoteEject.hide();
	remoteStop.hide();	
	
	int sysStat;
	sysStat = System.getStatus();
	if (sysStat==-1) {
		remotePlay.show();
		remotePause.hide();
		remoteEject.hide();
		remoteStop.show();
		}
	if (sysStat==0) {
		remotePlay.show();
		remotePause.hide();
		remoteEject.show();
		remoteStop.hide();		
		}
	if (sysStat==1) {
		remotePlay.hide();
		remotePause.show();
		remoteEject.hide();
		remoteStop.show();	
		}	

	string s = hiddenTicker.getText();	
	int v = strsearch(s, " - ");			
	string s1 = strleft (s, v);
	string s2 = strright (s, strlen(s) - 3 - v);
	ArtistText.setText(s1);
	TitleText.setText(s2);
				
}


// Playpause icons, song info sparsing
System.onScriptUnloading(){
	delete songInfoTimer;
	delete ArtistTickertimer;
}

System.onPlay(){
	songInfoTimer.start();
	PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-play");
	
	remotePlay.hide();
	remotePause.show();
	remoteEject.hide();
	remoteStop.show();		
}

System.onStop(){
	songInfoTimer.stop();
	frequencyText.setText("");
	bitrateText.setText("");
        MonoTxt.hide();
        StereoTxt.hide();
	PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-stop");
	
	remoteSeekFull.hide();
	
	remotePlay.show();
	remotePause.hide();
	remoteEject.show();
	remoteStop.hide();		
}

System.onResume(){
	songInfoTimer.start();
	PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-play");
	
	remotePlay.hide();
	remotePause.show();
	remoteEject.hide();
	remoteStop.show();	
}

System.onPause(){
	songInfoTimer.stop();
	PlayStatusIcon.setXMLParam("image", "player.remote-playstatus-pause");
	
	remotePlay.show();
	remotePause.hide();
	remoteEject.hide();
	remoteStop.show();	
}


infoHiddenText.onTextChanged(String newtxt) {
  if(newtxt=="-") {
    infoHiddenText.setText("");
	return;
  }
  String tkn, songinfo;
  songinfo = strupper(newtxt);

  MonoTxt.hide();
  StereoTxt.hide();
  if(strsearch(songinfo, "STEREO") > 0) StereoTxt.show();
}

songInfoTimer.onTimer(){
String tkn;
	SongInfoString = infoHiddenText.getText();

	tkn = tokenizeSongInfo("Bitrate", SongInfoString);
	if(tkn != "") {bitrateText.setText(tkn);}

	tkn = tokenizeSongInfo("Channels", SongInfoString);

	tkn = tokenizeSongInfo("Frequency", SongInfoString);
	if(tkn != "") {frequencyText.setText(tkn);}
}

tokenizeSongInfo(String tkn, String sinfo){
int searchResult;
String rtn;
if (tkn=="Bitrate"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(rtn, "kbps");
			if (searchResult>0) return Strleft(rtn, 3);
		}
		return "";
}

if (tkn=="Channels"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(rtn, "tereo");
			StereoTxt.show();
			MonoTxt.hide();
			if (searchResult>0) return rtn;
			searchResult = strsearch(rtn, "ono");
			MonoTxt.show();
			StereoTxt.hide();
			if (searchResult>0) return rtn;
		}
		return "";
}
if (tkn=="Frequency"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(strlower(rtn), "khz");
			if (searchResult>0) return Strleft(rtn, 2);
		}
		return "";
}
if (tkn=="ABR"){
		for (int i = 0; i < 5; i++) {
			rtn = getToken(sinfo, " ", i);
			searchResult = strsearch(rtn, "bps)");
			if (searchResult>0) return rtn;
		}
		return "";
}


else return "";
}


//  Song Artist & song title text
System.onTitleChange(string newtitle) {
			int v = strsearch(newtitle, " - ");			
			string s1 = strleft (newtitle, v);
			string s2 = strright (newtitle, strlen(newtitle) - 3 - v);
			ArtistText.setText(s1);
			TitleText.setText(s2);
}


// Song Position Seeker (don't like anims with maps)
	remoteSeek.onleftbuttondown(int x, int y) {
		seeking = 1;
 		x= x-remoteSeek.getleft();
 		y= y-remoteSeek.gettop();
 		if (remoteSeekMap.inregion(x,y)) {
  			now= remoteSeekMap.getvalue(x,y);
  			remoteSeekFull.setregionfrommap(remoteSeekMap,now,1);
 			updateSeeker(x, y, remoteSeekMap, remoteSeek, ArtistText, TitleText);
 		}
	}

	remoteSeek.onmousemove(int x, int y){
 		if (seeking) {
  			x= x-remoteSeek.getleft();
  			y= y-remoteSeek.gettop();
  				if (remoteSeekMap.inregion(x,y)) {
   					now= remoteSeekMap.getvalue(x,y);
   					remoteSeekFull.setregionfrommap(remoteSeekMap,now,1);
   					updateSeeker(x, y, remoteSeekMap, remoteSeek, ArtistText, TitleText);
   				}
 		}
	}

	remoteSeek.onleftbuttonup(int x, int y){
 		now = now/255*system.getplayitemlength();
 		seekto(now);
 		seeking=0;
 		ArtistTickertimer.start();
	}

	hidremoteseek.onpostedposition(int p){
 		if (!seeking){
	 		remoteSeekFull.show();remoteSeekFull.setregionfrommap(remoteSeekMap,p,1);
	 	}
	}
// 
//	System.onstop(){       
// 		remoteSeekFull.hide();
//	}


	ArtistTickertimer.onTimer() {
			string s = hiddenTicker.getText();	
			int v = strsearch(s, " - ");			
			string s1 = strleft (s, v);
			string s2 = strright (s, strlen(s) - 3 - v);
			ArtistText.setText(s1);
			TitleText.setText(s2);
			
			stop();
	}


	remoteSeek.onLeftButtonUp(int x, int y) {
  		seeking = 0;
  		setTempText("");
	} 

	updateSeeker(int x, int y, map remoteSeekMap, layer remoteSeek, text ArtistText, text TitleText) {
		int v = remoteSeekMap.getValue(x, y);
		if (v > 0) {
			if (System.getPlayItemLength() >= 0) {
				float len = System.getPlayItemLength();
				int p = (v * 100) / 255;
				int s = (v * len) / 255;
				setTempText("Seeking To Position:", System.integerToTime(s) + " / " + System.integerToTime(len) );
			}
		}
	}

	hidremoteseek.onSetFinalPosition(int p) {
		ArtistText.setText("");
	}

	setTempText(String txt, String txt2) {
  		ArtistTickertimer.stop();
  		ArtistText.setText(txt);
		TitleText.setText(txt2);
  		ArtistTickertimer.start();
	}

	emptyTempText() {
			string s = hiddenTicker.getText();	
			int v = strsearch(s, " - ");			
			string s1 = strleft (s, v);
			string s2 = strright (s, strlen(s) - 3 - v);
			ArtistText.setText(s1);
			TitleText.setText(s2);
			
			ArtistTickertimer.stop();
	}

