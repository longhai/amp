/*____________________________
 BLAKK - Video Component
 Design by: iamvica.com
 Script kittying by: eXaltic.com
____________________________*/

#include <lib/std.mi>

Function resizeObjects();

Global Layout mainvideo;
Global Group frameGroup, vidControls;
Global Text PlayedText, RemainText;
Global Button vidPlay, vidPause, vidStop, vidEject;
Global Slider vidSeeker;

Global Timer DoubleDisplayTimer;

System.onScriptLoaded() {
 
	mainvideo = getContainer("VideoWindow").getLayout("normal");
	frameGroup = mainvideo.getObject("wasabi.videoframe.layout");
	vidControls = mainvideo.getObject("BLAKK.video.ctrols");
	
	PlayedText = frameGroup.getObject("timer-elapsed");
	RemainText = frameGroup.getObject("timer-remain");

	vidStop = vidControls.getObject("blakk.video-stop");
	vidEject = vidControls.getObject("blakk.video-eject");
	vidPause = vidControls.getObject("blakk.video-pause"); 
	vidPlay = vidControls.getObject("blakk.video-play");

	vidPlay.hide(); // Yes, hide all switchable buttons on start
	vidPause.hide();
	vidEject.hide();
	vidStop.hide();	

	DoubleDisplayTimer = new Timer;
 	DoubleDisplayTimer.setDelay(500);
	DoubleDisplayTimer.start();
	
	int sysStat;
	sysStat = System.getStatus();
	if (sysStat==-1) {
		vidPlay.show();
		vidPause.hide();
		vidEject.hide();
		vidStop.show();
		}
	if (sysStat==0) {
		vidPlay.show();
		vidPause.hide();
		vidEject.show();
		vidStop.hide();		
		}
	if (sysStat==1) {
		vidPlay.hide();
		vidPause.show();
		vidEject.hide();
		vidStop.show();	
		}	

	int layout_w = mainvideo.getWidth();
	int w = (layout_w - 100)/2;
	vidControls.setXMLParam("x", System.integerToString(w));
	
	vidSeeker = mainvideo.getObject("blakk.video-seeker");
	
	float len = System.getPlayItemLength();
	int p = vidSeeker.getPosition();
	float f = p;
	f = f / 255 * 100;
	int np = len * f / 100;
	RemainText.setText("-" + integerToTime(len - np));
	PlayedText.setText(integerToTime(np));
		
}


// Playpause icons, song info sparsing
System.onScriptUnloading(){
	delete DoubleDisplayTimer;
}

System.onPlay(){
	DoubleDisplayTimer.start();
	vidPlay.hide();
	vidPause.show();
	vidEject.hide();
	vidStop.show();		
}

System.onStop(){
	DoubleDisplayTimer.stop();
	vidPlay.show();
	vidPause.hide();
	vidEject.show();
	vidStop.hide();		
}

System.onResume(){
	vidPlay.hide();
	vidPause.show();
	vidEject.hide();
	vidStop.show();	
}

System.onPause(){
	vidPlay.show();
	vidPause.hide();
	vidEject.hide();
	vidStop.show();	
}


//  Song Artist & song title text
System.onTitleChange(string newtitle) {
	PlayedText.setText(System.getPlayItemMetaDataString("TIMEELAPSED"));
	RemainText.setText(System.getPlayItemMetaDataString("TIMEREMAINING"));
}

DoubleDisplayTimer.onTimer() {
  	stop();
	if (System.getPlayItemLength() >= 0) {
			float len = System.getPlayItemLength();
			int p = vidSeeker.getPosition();
			float f = p;
			f = f / 255 * 100;
			int np = len * f / 100;
			RemainText.setText("-" + integerToTime(len - np));
			PlayedText.setText(integerToTime(np));

	}
	start();
}

vidSeeker.onSetPosition(int p) {
	float len = System.getPlayItemLength();
	int p = vidSeeker.getPosition();
	float f = p;
	f = f / 255 * 100;
	int np = len * f / 100;
	RemainText.setText("-" + integerToTime(len - np));
	PlayedText.setText(integerToTime(np));
}


// Center Controls Group
resizeObjects() {
int layout_w = mainvideo.getWidth();
int w = (layout_w - 100)/2;
vidControls.setXMLParam("x", System.integerToString(w));
}

mainvideo.onResize(int new_x, int new_y, int new_w, int new_h) {
resizeObjects();
}